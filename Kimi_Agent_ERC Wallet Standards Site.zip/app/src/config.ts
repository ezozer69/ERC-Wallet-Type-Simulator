// =============================================================================
// VaultChain - Crypto Wallet Company Configuration
// =============================================================================
// All site content is configured here. Components render nothing when their
// primary config fields are empty strings or empty arrays.
// =============================================================================

// -----------------------------------------------------------------------------
// Site Config
// -----------------------------------------------------------------------------
export interface SiteConfig {
  title: string;
  description: string;
  language: string;
  keywords: string;
  ogImage: string;
  canonical: string;
}

export const siteConfig: SiteConfig = {
  title: "VaultChain - Premium Crypto Wallet Solutions",
  description: "Enterprise-grade crypto wallet supporting all ERC standards. Secure, intuitive, and powerful digital asset management for developers and institutions.",
  language: "en",
  keywords: "crypto wallet, ERC-20, ERC-721, ERC-1155, Ethereum, blockchain, DeFi, NFT, token standards",
  ogImage: "/images/hero-banner.jpg",
  canonical: "https://vaultchain.io",
};

// -----------------------------------------------------------------------------
// Navigation Config - With Dropdown for ERC Standards
// -----------------------------------------------------------------------------
export interface NavDropdownItem {
  name: string;
  href: string;
}

export interface NavLink {
  name: string;
  href: string;
  icon: string;
  dropdown?: NavDropdownItem[];
}

export interface NavigationConfig {
  brandName: string;
  brandSubname: string;
  tagline: string;
  navLinks: NavLink[];
  ctaButtonText: string;
}

export const navigationConfig: NavigationConfig = {
  brandName: "VaultChain",
  brandSubname: "Secure Digital Assets",
  tagline: "Enterprise Crypto Wallet Solutions",
  navLinks: [
    {
      name: "Home",
      href: "#home",
      icon: "Home",
    },
    {
      name: "ERC Standards",
      href: "#standards",
      icon: "BookOpen",
      dropdown: [
        { name: "ERC-20 Fungible Tokens", href: "#erc20" },
        { name: "ERC-721 NFTs", href: "#erc721" },
        { name: "ERC-1155 Multi-Token", href: "#erc1155" },
        { name: "ERC-777 Advanced", href: "#erc777" },
        { name: "ERC-4626 Vaults", href: "#erc4626" },
        { name: "ERC-223 Secure", href: "#erc223" },
        { name: "ERC-721A Efficient", href: "#erc721a" },
      ],
    },
    {
      name: "Solutions",
      href: "#solutions",
      icon: "Sparkles",
    },
    {
      name: "Security",
      href: "#security",
      icon: "Shield",
    },
    {
      name: "Contact",
      href: "#contact",
      icon: "Mail",
    },
  ],
  ctaButtonText: "Get Started",
};

// -----------------------------------------------------------------------------
// Preloader Config
// -----------------------------------------------------------------------------
export interface PreloaderConfig {
  brandName: string;
  brandSubname: string;
  yearText: string;
}

export const preloaderConfig: PreloaderConfig = {
  brandName: "VaultChain",
  brandSubname: "Wallet Solutions",
  yearText: "Est. 2024",
};

// -----------------------------------------------------------------------------
// Hero Config
// -----------------------------------------------------------------------------
export interface HeroStat {
  value: number;
  suffix: string;
  label: string;
}

export interface HeroConfig {
  scriptText: string;
  mainTitle: string;
  ctaButtonText: string;
  ctaTarget: string;
  stats: HeroStat[];
  decorativeText: string;
  backgroundImage: string;
}

export const heroConfig: HeroConfig = {
  scriptText: "Enterprise-Grade Security Meets Intuitive Design",
  mainTitle: "Your Digital Assets\nDeserve Better",
  ctaButtonText: "Explore ERC Standards",
  ctaTarget: "#standards",
  stats: [
    { value: 50, suffix: "+", label: "ERC Standards Supported" },
    { value: 99.9, suffix: "%", label: "Uptime Guaranteed" },
    { value: 10, suffix: "M+", label: "Transactions Secured" },
  ],
  decorativeText: "SECURE • FAST • RELIABLE",
  backgroundImage: "/images/hero-banner.jpg",
};

// -----------------------------------------------------------------------------
// ERC Standards Showcase Config (Wine Showcase adapted)
// -----------------------------------------------------------------------------
export interface ERCStandard {
  id: string;
  name: string;
  subtitle: string;
  year: string;
  image: string;
  filter: string;
  glowColor: string;
  description: string;
  keyFeatures: string;
  useCases: string;
  developerNote: string;
}

export interface ERCFeature {
  icon: string;
  title: string;
  description: string;
}

export interface ERCQuote {
  text: string;
  attribution: string;
  prefix: string;
}

export interface ERCShowcaseConfig {
  scriptText: string;
  subtitle: string;
  mainTitle: string;
  standards: ERCStandard[];
  features: ERCFeature[];
  quote: ERCQuote;
}

export const ercShowcaseConfig: ERCShowcaseConfig = {
  scriptText: "Comprehensive Token Support",
  subtitle: "ALL MAJOR ERC STANDARDS",
  mainTitle: "Developer-First\nWallet Architecture",
  standards: [
    {
      id: "erc20",
      name: "ERC-20",
      subtitle: "Fungible Token Standard",
      year: "2015",
      image: "/images/erc20-token.jpg",
      filter: "",
      glowColor: "bg-amber-500/20",
      description: "The foundational standard for fungible tokens on Ethereum. Each token is identical and interchangeable, making ERC-20 perfect for currencies, voting tokens, and staking mechanisms.",
      keyFeatures: "• totalSupply() - Get total token circulation\n• balanceOf() - Check account balances\n• transfer() - Direct token transfers\n• approve() / allowance() - Delegated spending\n• transferFrom() - Third-party transfers",
      useCases: "Stablecoins (USDC, USDT), Governance tokens (UNI, AAVE), Utility tokens, Staking rewards",
      developerNote: "Use OpenZeppelin's ERC20 contract for secure implementations. Always verify token contracts on Etherscan before integration.",
    },
    {
      id: "erc721",
      name: "ERC-721",
      subtitle: "Non-Fungible Token Standard",
      year: "2018",
      image: "/images/erc721-nft.jpg",
      filter: "",
      glowColor: "bg-purple-500/20",
      description: "The gold standard for unique digital assets. Each ERC-721 token has a distinct identifier and cannot be replicated, enabling true digital ownership and provenance tracking.",
      keyFeatures: "• ownerOf(tokenId) - Verify ownership\n• safeTransferFrom() - Secure transfers with receiver validation\n• approve() - Single-token delegation\n• setApprovalForAll() - Operator management\n• tokenURI() - Metadata retrieval",
      useCases: "Digital art & collectibles, Gaming assets, Real estate tokenization, Identity verification, Event tickets",
      developerNote: "Implement ERC721URIStorage for metadata management. Use IPFS for decentralized storage of NFT assets.",
    },
    {
      id: "erc1155",
      name: "ERC-1155",
      subtitle: "Multi-Token Standard",
      year: "2019",
      image: "/images/erc1155-multi.jpg",
      filter: "",
      glowColor: "bg-cyan-500/20",
      description: "The efficient multi-token standard that combines fungible and non-fungible capabilities in a single contract. Batch operations save significant gas costs.",
      keyFeatures: "• balanceOfBatch() - Multiple balance queries\n• safeBatchTransferFrom() - Bulk transfers\n• setApprovalForAll() - Universal operator approval\n• onERC1155Received() - Contract reception hook\n• Single contract, multiple token types",
      useCases: "Gaming item ecosystems, Mixed NFT/marketplace platforms, Loyalty programs, Multi-asset portfolios",
      developerNote: "Ideal for gaming projects requiring both currency and unique items. Batch transfers can save 40-60% on gas compared to individual transfers.",
    },
    {
      id: "erc777",
      name: "ERC-777",
      subtitle: "Advanced Token Standard",
      year: "2019",
      image: "/images/erc777-advanced.jpg",
      filter: "",
      glowColor: "bg-rose-500/20",
      description: "An advanced token standard with hooks and operators. Enables sophisticated transfer logic and prevents tokens from being locked in incompatible contracts.",
      keyFeatures: "• tokensReceived() hook - Post-transfer callback\n• tokensToSend() hook - Pre-transfer validation\n• authorizeOperator() - Delegated senders\n• send() - Single-step transfers\n• ERC-1820 registry integration",
      useCases: "DeFi protocols requiring callback logic, Automated trading systems, Complex token vesting, Cross-chain bridges",
      developerNote: "Note: OpenZeppelin has deprecated ERC-777 due to reentrancy concerns. Use with caution and implement proper security measures.",
    },
    {
      id: "erc4626",
      name: "ERC-4626",
      subtitle: "Tokenized Vault Standard",
      year: "2022",
      image: "/images/erc4626-vault.jpg",
      filter: "",
      glowColor: "bg-emerald-500/20",
      description: "The yield-bearing vault standard that revolutionized DeFi. Provides a unified interface for depositing assets and receiving shares representing vault ownership.",
      keyFeatures: "• deposit() / mint() - Asset entry with share calculation\n• withdraw() / redeem() - Asset exit mechanisms\n• previewDeposit() - Pre-calculate share amounts\n• convertToShares() - Asset-to-share conversion\n• totalAssets() - Vault TVL tracking",
      useCases: "Yield aggregators (Yearn), Lending protocols (Aave, Compound), Liquid staking tokens, Automated strategies",
      developerNote: "Extensions: ERC-7540 for async vaults, ERC-7575 for multi-asset vaults. Always check for inflation attack vulnerabilities.",
    },
    {
      id: "erc223",
      name: "ERC-223",
      subtitle: "Secure Transfer Standard",
      year: "2017",
      image: "/images/erc223-secure.jpg",
      filter: "",
      glowColor: "bg-green-500/20",
      description: "Addresses the critical ERC-20 flaw where tokens sent to contract addresses can be permanently lost. ERC-223 ensures safe token reception with built-in validation.",
      keyFeatures: "• tokenReceived() callback - Contract notification\n• Unified transfer() function - Works for EOA and contracts\n• Automatic rejection of incompatible recipients\n• Single-step transfers (no approve needed)\n• 50% gas savings vs ERC-20 approve+transfer",
      useCases: "Secure token transfers, DEX integrations, Payment systems, Any application prioritizing safety",
      developerNote: "Not backward compatible with ERC-20. Adopted by Dex223 DEX. Prevents the $80M+ in tokens lost to ERC-20 contract transfers.",
    },
    {
      id: "erc721a",
      name: "ERC-721A",
      subtitle: "Gas-Efficient NFT Standard",
      year: "2022",
      image: "/images/erc721a-efficient.jpg",
      filter: "",
      glowColor: "bg-indigo-500/20",
      description: "Azuki's optimized implementation of ERC-721 for batch minting. Achieves 7x gas savings when minting multiple NFTs in a single transaction.",
      keyFeatures: "• Batch minting with quantity parameter\n• Optimized storage layout - Single write per batch\n• _numberMinted() tracking\n• Full ERC-721 compatibility\n• ERC721AQueryable for enumeration",
      useCases: "Large NFT collections, Gaming assets, Membership passes, Any project requiring bulk minting",
      developerNote: "Trade-off: Higher gas on transfers for minting savings. Used by Azuki, goblintown, Moonbirds. Install via: npm install erc721a",
    },
  ],
  features: [
    {
      icon: "Shield",
      title: "Secure by Design",
      description: "Multi-signature support, hardware wallet integration, and audited smart contract interactions.",
    },
    {
      icon: "Zap",
      title: "Gas Optimization",
      description: "Intelligent transaction batching and gas estimation for cost-effective operations across all standards.",
    },
    {
      icon: "Layers",
      title: "Multi-Chain Support",
      description: "Seamless asset management across Ethereum, Polygon, Arbitrum, Optimism, and more.",
    },
  ],
  quote: {
    text: "VaultChain has transformed how we handle digital assets. The comprehensive ERC support and developer-friendly APIs are unmatched.",
    attribution: "Sarah Chen, CTO at DeFi Protocol",
    prefix: "Developer Testimonial",
  },
};

// -----------------------------------------------------------------------------
// Solutions Carousel Config
// -----------------------------------------------------------------------------
export interface SolutionSlide {
  image: string;
  title: string;
  subtitle: string;
  area: string;
  unit: string;
  description: string;
}

export interface SolutionsCarouselConfig {
  scriptText: string;
  subtitle: string;
  mainTitle: string;
  locationTag: string;
  slides: SolutionSlide[];
}

export const solutionsCarouselConfig: SolutionsCarouselConfig = {
  scriptText: "Enterprise Solutions",
  subtitle: "BUILT FOR SCALE",
  mainTitle: "Wallet Infrastructure\nFor Every Need",
  locationTag: "Global Infrastructure",
  slides: [
    {
      image: "/images/wallet-app.jpg",
      title: "Mobile Wallet SDK",
      subtitle: "White-Label Solution",
      area: "99.99",
      unit: "% Uptime",
      description: "Embed a fully customizable crypto wallet into your mobile app. Support for all ERC standards with biometric authentication and secure enclave key storage.",
    },
    {
      image: "/images/security.jpg",
      title: "Institutional Custody",
      subtitle: "Multi-Sig Security",
      area: "256-bit",
      unit: "Encryption",
      description: "Enterprise-grade custody solution with multi-signature requirements, role-based access control, and comprehensive audit trails for institutional clients.",
    },
    {
      image: "/images/defi-ecosystem.jpg",
      title: "DeFi Integration",
      subtitle: "Protocol Connectivity",
      area: "200+",
      unit: "Protocols",
      description: "Direct integration with leading DeFi protocols. Enable yield farming, lending, and staking directly from your wallet with standardized ERC-4626 vault support.",
    },
  ],
};

// -----------------------------------------------------------------------------
// Security & Compliance Config (Museum adapted)
// -----------------------------------------------------------------------------
export interface SecurityTimelineEvent {
  year: string;
  event: string;
}

export interface SecurityTabContent {
  title: string;
  description: string;
  highlight: string;
}

export interface SecurityTab {
  id: string;
  name: string;
  icon: string;
  image: string;
  content: SecurityTabContent;
}

export interface SecurityQuote {
  prefix: string;
  text: string;
  attribution: string;
}

export interface SecurityConfig {
  scriptText: string;
  subtitle: string;
  mainTitle: string;
  introText: string;
  timeline: SecurityTimelineEvent[];
  tabs: SecurityTab[];
  openingHours: string;
  openingHoursLabel: string;
  ctaButtonText: string;
  yearBadge: string;
  yearBadgeLabel: string;
  quote: SecurityQuote;
  founderPhotoAlt: string;
  founderPhoto: string;
}

export const securityConfig: SecurityConfig = {
  scriptText: "Security First",
  subtitle: "PROTECTION AT EVERY LAYER",
  mainTitle: "Bank-Grade Security\nFor Digital Assets",
  introText: "Our multi-layered security architecture combines hardware security modules, encrypted key storage, and real-time threat monitoring to protect your assets 24/7.",
  timeline: [
    { year: "2024", event: "SOC 2 Type II Certification" },
    { year: "2024", event: "Bug Bounty Program Launch" },
    { year: "2025", event: "Insurance Coverage Expansion" },
    { year: "2025", event: "Quantum-Resistant Research" },
  ],
  tabs: [
    {
      id: "encryption",
      name: "Encryption",
      icon: "Lock",
      image: "/images/security.jpg",
      content: {
        title: "Military-Grade Encryption",
        description: "All private keys are encrypted using AES-256-GCM and stored in secure enclaves. Transactions are signed within hardware-isolated environments, ensuring keys never exist in plaintext in application memory.",
        highlight: "256-bit AES Encryption",
      },
    },
    {
      id: "multisig",
      name: "Multi-Sig",
      icon: "Users",
      image: "/images/wallet-app.jpg",
      content: {
        title: "Flexible Multi-Signature",
        description: "Configure custom signing thresholds and approval workflows. Support for Gnosis Safe integration, social recovery mechanisms, and time-locked transactions for enhanced security.",
        highlight: "M-of-N Signing Schemes",
      },
    },
    {
      id: "compliance",
      name: "Compliance",
      icon: "CheckCircle",
      image: "/images/defi-ecosystem.jpg",
      content: {
        title: "Regulatory Compliance",
        description: "Built-in AML screening, transaction monitoring, and audit trails. Support for travel rule compliance and integration with leading KYC/AML providers for institutional requirements.",
        highlight: "Global Regulatory Standards",
      },
    },
  ],
  openingHours: "24/7/365",
  openingHoursLabel: "Security Monitoring",
  ctaButtonText: "View Security Docs",
  yearBadge: "2024",
  yearBadgeLabel: "Founded",
  quote: {
    prefix: "Security Philosophy",
    text: "Security is not a feature—it's the foundation. Every line of code, every architectural decision, and every process is designed with asset protection as the primary objective.",
    attribution: "VaultChain Security Team",
  },
  founderPhotoAlt: "Security Operations Center",
  founderPhoto: "/images/security.jpg",
};

// -----------------------------------------------------------------------------
// News & Resources Config
// -----------------------------------------------------------------------------
export interface NewsArticle {
  id: number;
  image: string;
  title: string;
  excerpt: string;
  date: string;
  category: string;
}

export interface Testimonial {
  name: string;
  role: string;
  text: string;
  rating: number;
}

export interface StoryQuote {
  prefix: string;
  text: string;
  attribution: string;
}

export interface StoryTimelineItem {
  value: string;
  label: string;
}

export interface NewsConfig {
  scriptText: string;
  subtitle: string;
  mainTitle: string;
  viewAllText: string;
  readMoreText: string;
  articles: NewsArticle[];
  testimonialsScriptText: string;
  testimonialsSubtitle: string;
  testimonialsMainTitle: string;
  testimonials: Testimonial[];
  storyScriptText: string;
  storySubtitle: string;
  storyTitle: string;
  storyParagraphs: string[];
  storyTimeline: StoryTimelineItem[];
  storyQuote: StoryQuote;
  storyImage: string;
  storyImageCaption: string;
}

export const newsConfig: NewsConfig = {
  scriptText: "Latest Updates",
  subtitle: "NEWS & INSIGHTS",
  mainTitle: "Developer Resources\n& Announcements",
  viewAllText: "View All Articles",
  readMoreText: "Read More",
  articles: [
    {
      id: 1,
      image: "/images/erc4626-vault.jpg",
      title: "ERC-4626 Integration Guide",
      excerpt: "Complete walkthrough for integrating yield-bearing vaults into your wallet application with best practices.",
      date: "Feb 15, 2026",
      category: "Developer Guide",
    },
    {
      id: 2,
      image: "/images/erc721a-efficient.jpg",
      title: "Gas Optimization Strategies",
      excerpt: "How ERC-721A can reduce minting costs by 7x and improve user experience for NFT collections.",
      date: "Feb 10, 2026",
      category: "Technical",
    },
    {
      id: 3,
      image: "/images/security.jpg",
      title: "Security Audit Results",
      excerpt: "Third-party security audit confirms VaultChain's industry-leading security posture.",
      date: "Feb 5, 2026",
      category: "Security",
    },
    {
      id: 4,
      image: "/images/defi-ecosystem.jpg",
      title: "Multi-Chain Expansion",
      excerpt: "VaultChain now supports 15+ EVM-compatible networks with unified ERC standard support.",
      date: "Jan 28, 2026",
      category: "Product Update",
    },
  ],
  testimonialsScriptText: "Community Voice",
  testimonialsSubtitle: "TRUSTED BY DEVELOPERS",
  testimonialsMainTitle: "What Builders Say",
  testimonials: [
    {
      name: "Michael Torres",
      role: "Lead Developer, NFT Marketplace",
      text: "The ERC-721A integration saved us thousands in gas costs. VaultChain's APIs are intuitive and well-documented.",
      rating: 5,
    },
    {
      name: "Emily Watson",
      role: "CTO, DeFi Protocol",
      text: "Finally, a wallet that truly understands ERC-4626 vaults. The preview functions and share calculations are spot-on.",
      rating: 5,
    },
    {
      name: "David Kim",
      role: "Smart Contract Engineer",
      text: "Security-first approach with comprehensive ERC support. Our audit passed with flying colors using VaultChain's SDK.",
      rating: 5,
    },
  ],
  storyScriptText: "Our Journey",
  storySubtitle: "BUILDING THE FUTURE",
  storyTitle: "A Commitment to\nOpen Standards",
  storyParagraphs: [
    "VaultChain was founded with a simple mission: make digital asset management secure, intuitive, and accessible to everyone. We believe in the power of open standards and the innovation they enable.",
    "Our team of blockchain engineers and security experts has built a wallet infrastructure that supports the full spectrum of ERC standards—from the foundational ERC-20 to the cutting-edge ERC-4626 vault protocol.",
    "We're not just building a wallet; we're building the infrastructure for the future of finance. Every feature, every integration, and every line of code is designed to empower developers and protect users.",
  ],
  storyTimeline: [
    { value: "50+", label: "ERC Standards" },
    { value: "15+", label: "Blockchains" },
    { value: "200+", label: "DeFi Protocols" },
    { value: "1M+", label: "Users" },
  ],
  storyQuote: {
    prefix: "Our Vision",
    text: "We envision a world where digital assets are as easy to manage as traditional finance, with security that exceeds banking standards.",
    attribution: "VaultChain Founding Team",
  },
  storyImage: "/images/hero-banner.jpg",
  storyImageCaption: "VaultChain Headquarters",
};

// -----------------------------------------------------------------------------
// Contact Form Config
// -----------------------------------------------------------------------------
export interface ContactInfoItem {
  icon: string;
  label: string;
  value: string;
  subtext: string;
}

export interface ContactFormFields {
  nameLabel: string;
  namePlaceholder: string;
  emailLabel: string;
  emailPlaceholder: string;
  phoneLabel: string;
  phonePlaceholder: string;
  visitDateLabel: string;
  visitorsLabel: string;
  visitorsOptions: string[];
  messageLabel: string;
  messagePlaceholder: string;
  submitText: string;
  submittingText: string;
  successMessage: string;
  errorMessage: string;
}

export interface ContactFormConfig {
  scriptText: string;
  subtitle: string;
  mainTitle: string;
  introText: string;
  contactInfoTitle: string;
  contactInfo: ContactInfoItem[];
  form: ContactFormFields;
  privacyNotice: string;
  formEndpoint: string;
}

export const contactFormConfig: ContactFormConfig = {
  scriptText: "Get In Touch",
  subtitle: "CONTACT US",
  mainTitle: "Let's Build\nTogether",
  introText: "Whether you're integrating wallet functionality, exploring ERC standards, or need enterprise solutions, our team is here to help.",
  contactInfoTitle: "Contact Information",
  contactInfo: [
    {
      icon: "MapPin",
      label: "Headquarters",
      value: "San Francisco, CA",
      subtext: "Global team across 12 time zones",
    },
    {
      icon: "Mail",
      label: "Email",
      value: "developers@vaultchain.io",
      subtext: "Technical support & inquiries",
    },
    {
      icon: "Clock",
      label: "Support Hours",
      value: "24/7 Developer Support",
      subtext: "For enterprise clients",
    },
    {
      icon: "Github",
      label: "GitHub",
      value: "github.com/vaultchain",
      subtext: "Open source SDKs & examples",
    },
  ],
  form: {
    nameLabel: "Full Name",
    namePlaceholder: "John Doe",
    emailLabel: "Email Address",
    emailPlaceholder: "john@company.com",
    phoneLabel: "Company",
    phonePlaceholder: "Your company name",
    visitDateLabel: "Preferred Contact Time",
    visitorsLabel: "Project Type",
    visitorsOptions: ["Wallet Integration", "ERC Standard Support", "Enterprise Solution", "Partnership", "Other"],
    messageLabel: "Message",
    messagePlaceholder: "Tell us about your project and requirements...",
    submitText: "Send Message",
    submittingText: "Sending...",
    successMessage: "Thank you! We'll be in touch within 24 hours.",
    errorMessage: "Something went wrong. Please try again or email us directly.",
  },
  privacyNotice: "By submitting this form, you agree to our Privacy Policy and Terms of Service.",
  formEndpoint: "https://formspree.io/f/YOUR_FORM_ID",
};

// -----------------------------------------------------------------------------
// Footer Config
// -----------------------------------------------------------------------------
export interface SocialLink {
  icon: string;
  label: string;
  href: string;
}

export interface FooterLink {
  name: string;
  href: string;
}

export interface FooterLinkGroup {
  title: string;
  links: FooterLink[];
}

export interface FooterContactItem {
  icon: string;
  text: string;
}

export interface FooterConfig {
  brandName: string;
  tagline: string;
  description: string;
  socialLinks: SocialLink[];
  linkGroups: FooterLinkGroup[];
  contactItems: FooterContactItem[];
  newsletterLabel: string;
  newsletterPlaceholder: string;
  newsletterButtonText: string;
  newsletterSuccessText: string;
  newsletterErrorText: string;
  newsletterEndpoint: string;
  copyrightText: string;
  legalLinks: string[];
  icpText: string;
  backToTopText: string;
  ageVerificationText: string;
}

export const footerConfig: FooterConfig = {
  brandName: "VaultChain",
  tagline: "Secure Digital Assets",
  description: "Enterprise-grade crypto wallet supporting all ERC standards. Built by developers, for developers.",
  socialLinks: [
    { icon: "Twitter", label: "Twitter", href: "https://twitter.com/vaultchain" },
    { icon: "Github", label: "GitHub", href: "https://github.com/vaultchain" },
    { icon: "Linkedin", label: "LinkedIn", href: "https://linkedin.com/company/vaultchain" },
    { icon: "Youtube", label: "YouTube", href: "https://youtube.com/vaultchain" },
  ],
  linkGroups: [
    {
      title: "ERC Standards",
      links: [
        { name: "ERC-20 Tokens", href: "#erc20" },
        { name: "ERC-721 NFTs", href: "#erc721" },
        { name: "ERC-1155 Multi", href: "#erc1155" },
        { name: "ERC-4626 Vaults", href: "#erc4626" },
        { name: "View All", href: "#standards" },
      ],
    },
    {
      title: "Developers",
      links: [
        { name: "Documentation", href: "#docs" },
        { name: "API Reference", href: "#api" },
        { name: "SDK Downloads", href: "#sdk" },
        { name: "GitHub", href: "https://github.com/vaultchain" },
        { name: "Status", href: "#status" },
      ],
    },
  ],
  contactItems: [
    { icon: "Mail", text: "developers@vaultchain.io" },
    { icon: "MapPin", text: "San Francisco, CA" },
  ],
  newsletterLabel: "Stay Updated",
  newsletterPlaceholder: "Enter your email",
  newsletterButtonText: "Subscribe",
  newsletterSuccessText: "Thanks for subscribing!",
  newsletterErrorText: "Subscription failed. Please try again.",
  newsletterEndpoint: "https://formspree.io/f/YOUR_NEWSLETTER_ID",
  copyrightText: "© 2026 VaultChain. All rights reserved.",
  legalLinks: ["Privacy Policy", "Terms of Service", "Cookie Policy"],
  icpText: "",
  backToTopText: "Back to top",
  ageVerificationText: "",
};

// -----------------------------------------------------------------------------
// Scroll To Top Config
// -----------------------------------------------------------------------------
export interface ScrollToTopConfig {
  ariaLabel: string;
}

export const scrollToTopConfig: ScrollToTopConfig = {
  ariaLabel: "Back to top",
};
